# Data Structure & Algorithms using Python
This tutorial covers data structures and algorithms in python. Every tutorial has theory behind data structure or an algorithm, BIG O Complexity analysis and exercises that you can practice on.

To watch the videos, you can go check the playlist out at: https://www.youtube.com/playlist?list=PLeo1K3hjS3uu_n_a__MI_KktGTLYopZ12

To subscribe to codebasics youtube channel: https://www.youtube.com/c/codebasics
